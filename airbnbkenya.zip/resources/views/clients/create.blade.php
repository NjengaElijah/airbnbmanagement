<div class="form-group">
    <label for="first_name">First Name</label>
    <input type="text" name="first_name" id="" class="form-control">
</div>
<div class="form-group">
    <label for="last_name">Last Name</label>
    <input type="text" name="last_name" id="" class="form-control">
</div>
<div class="form-group">
    <label for="phone">Phone</label>
    <input type="text" name="phone" id="" class="form-control">
</div>
<div class="form-group">
    <label for="email">Email</label>
    <input type="text" name="email" id="" class="form-control">
</div>
<div class="form-group">
    <label for="notes">Notes</label>
    <input type="text" name="notes" id="" class="form-control">
</div>
