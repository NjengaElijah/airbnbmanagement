<?php
    $pagename = $property->name;
    $pagecramp = 'Create and manage room properties/rooms here !';
?>


<?php $__env->startSection('content'); ?>
    <div class=" p-1 ">
        <button is_modal="1" data-href="<?php echo e(route('property_delete',$property->id)); ?>" class="btn btn-danger btn-sm">Delete Property</button>
        <hr>

        <div class="card-columns mt-1">
            <form class="card" action="<?php echo e(route('property_edit', $property->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card-header">
                    <h5>Description</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="">Name</label>
                        <input class="form-control" type="text" name="name" value="<?php echo e($property->name); ?>"
                            id="">
                    </div>
                    <div class="form-group">
                        <label for="">Description</label>
                        <textarea class="form-control" type="text" name="description" id=""><?php echo e($property->description); ?></textarea>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="">Price</label>
                                <input class="form-control" type="text" name="price_per_night"
                                    value="<?php echo e($property->price_per_night); ?>" id="">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="">Discounted Price</label>
                                <input class="form-control" type="text" name="discounted_price"
                                    value="<?php echo e($property->discounted_price); ?>" id="">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="">Location</label>
                        <input class="form-control" type="text" name="location" value="<?php echo e($property->location); ?>"
                            id="">
                    </div>
                    <div class="form-group">
                        <label for="">Coordinates</label>
                        <input class="form-control" type="text" name="coordinates" value="<?php echo e($property->coordinates); ?>"
                            id="">
                    </div>
                    <div class="form-group">
                        <label for="">No Of Guests</label>
                        <input class="form-control" type="text" name="no_guests" value="<?php echo e($property->no_guests); ?>"
                            id="">
                    </div>
                    <div class="form-group">
                        <input class="btn btn-md btn-danger" type="submit" value="Update">
                    </div>
                </div>
            </form>
            <div class="card">
                <div class="card-header"><h5>Images</h5></div>
                <div class="card-body">
                    <form action="<?php echo e(route('property_image_upload', $property->id)); ?>" enctype="multipart/form-data"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="image">Upload Image</label>
                            <input type="file" name="image" class="form-control" id="">

                        </div>
                        <div class="form-group">
                            <input type="submit" class="btn btn-sm btn-info" value="Upload">
                        </div>
                    </form>
                    <div class="row">   
                        <?php $__currentLoopData = $property->photos(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="d-inline  border border-secondary rounde shaddow p-2 m-2">  
                            <img src="<?php echo e($photo['path']); ?>" alt="" class="d-block" style="max-width: 150px" >
                            <a is_modal="1" class="text-danger " style="cursor:pointer"  data-href="<?php echo e(route('remove_image',$photo['id'])); ?>">Remove </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header">
                    <h5> Room Types & Features</h5>
                </div>
                <div class="card-body">
                    <p>Assigned Room Features <i><b>click on a feature to remove it</b></i></p>
                    <?php $__currentLoopData = $property->features()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('property_de_assign_feature', $property->id)); ?>" class="d-inline m-1"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="feature_id" value="<?php echo e($feature->id); ?>">
                            <input type="submit" value="<?php echo e($feature->name); ?>" class="btn btn-sm btn-outline-success m-1">
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <p>Un Assigned Room Features  <i><b>click on a feature to add it</b></i>
                        <a href="#" class="float-right" is_modal="1" data-href="<?php echo e(route('feature_add')); ?>" >Add Feature</a>
                    </p>
                    <?php if(!count($property->unassignedFeatures())): ?>
                        <i class="text-center">You have assigned all features !</i>
                    <?php else: ?>
                    <?php $__currentLoopData = $property->unassignedFeatures(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('property_assign_feature', $property->id)); ?>" class="d-inline m-1"
                            method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="feature_id" value="<?php echo e($feature->id); ?>">
                            <input type="submit" value="<?php echo e($feature->name); ?>" class="btn btn-sm btn-outline-danger m-1">
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/properties/view.blade.php ENDPATH**/ ?>