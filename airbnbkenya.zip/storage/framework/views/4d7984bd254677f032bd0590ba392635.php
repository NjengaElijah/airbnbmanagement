<?php
    $pagename = 'Features';
    $pagecramp = 'Create and manage room features here !';
?>


<?php $__env->startSection('content'); ?>
    <div class=" p-1 ">
        <button is_modal="1" data-href="<?php echo e(route('feature_add')); ?>" class="btn btn-danger btn-sm">Add Feature</button>

                
                <div class="card-columns mt-1">
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            <div class="card-header">
                                <button  is_modal="1" data-href="<?php echo e(route('feature_delete',$feature->id)); ?>" class="close" >x</button>
                            </div>
                            <div class="card-body">
                                <h5><?php echo e($feature->name); ?></h5>
                                <p><?php echo e($feature->description); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/features/index.blade.php ENDPATH**/ ?>