<?php
    $pagename = 'Properties';
    $pagecramp = 'Create and manage room properties/rooms here !';
?>


<?php $__env->startSection('content'); ?>
    <div class=" p-1 ">
        <button is_modal="1" data-href="<?php echo e(route('property_add')); ?>" class="btn btn-danger btn-sm">Add Rooms</button>

                
                <div class="card-columns mt-1">
                    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">
                            
                            <?php if($room->mainPhoto()): ?>
                            <img class="card-img-top" src="<?php echo e($room->mainPhoto()->uPath()); ?>" alt="Card image cap">
                            <?php else: ?>
                            <div class="alert alert-danger">No Photo Uploaded</div>
                            <?php endif; ?>                            
                            <div class="card-header">
                                
                                <h5><?php echo e($room->name); ?></h5>
                            </div>
                            <div class="card-body">
                                
                                <p><?php echo $room->description; ?></p>
                            </div>
                            <div class="card-footer">
                                KES <?php echo e($room->discounted_price); ?> - <strike><?php echo e($room->price_per_night); ?></strike>

                                <a class="float-right btn btn-xs btn-info my-2" href="<?php echo e(route('property_view',$room->id)); ?>">View / Edit</a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/properties/index.blade.php ENDPATH**/ ?>