<?php
    $pagename = 'Apartments (Create and manage your parents)';
    $pagecramp = 'Apartments';
?>


<?php $__env->startSection('content'); ?>
    <div class="  ">
        <button is_modal="1" data-href="<?php echo e(route('apartment_add')); ?>" class="btn btn-danger btn-sm">Add Apartment</button>
        <div class="card mt-2">
            <div class="card-header">
                <div class="col-3">

                </div>
            </div>
            <div class="card-body">
                <table class="table table-sm table-condensed">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Names</th>
                            
                            <th>Location</th>
                            <th>Rooms</th>
                            <th>Client</th>
                            <th>Date Added</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $apartments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $apartment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($apartment->name); ?></td>
                                
                                <td><?php echo e($apartment->location); ?></td>
                                <td></td>
                                <td> <a href="#"><?php echo e($apartment->client->names()); ?></a> </td>
                                <td><?php echo e($apartment->created_at); ?></td>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/apartments/index.blade.php ENDPATH**/ ?>