

<div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" id="" class="form-control">
</div>
<div class="form-group">
    <label for="description">Description</label>
    <input type="text" name="description" id="" class="form-control">
</div>
<div class="form-group">
    <label for="location">Location</label>
    <input type="text" name="location" id="" class="form-control">
</div>
<div class="form-group">
    <label for="coordinates">Coordinates</label>
    <input type="text" name="coordinates" id="" class="form-control">
</div>
<div class="form-group">
    <label for="email">Client</label>
    <select name="client_id" class="form-control">
        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($client->id); ?>"><?php echo e($client->names()); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
<?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/apartments/create.blade.php ENDPATH**/ ?>