<div class="form-group">
    <label for="name">Name</label>
    <input type="text" name="name" id="" class="form-control" />
</div>
<div class="form-group">
    <label for="description">Description</label>
    <textarea type="text" name="description" id="" class="form-control"></textarea>
</div>
<div class="form-group">
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type1" checked>
        <label class="form-check-label" for="type1">
            Feature
        </label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="type" id="type2">
        <label class="form-check-label" for="type2">
            Type
        </label>
    </div>
</div>
<div class="alert alert-dark" role="alert"><i>Type is the room type e.g bedsitter, onebedroom. Features are like wifi,
        bathtub </i></div>
<?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/features/create.blade.php ENDPATH**/ ?>