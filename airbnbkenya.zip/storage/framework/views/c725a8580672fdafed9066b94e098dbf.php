<form method="post" action="<?php echo e($action); ?>" class="" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <?php echo csrf_field(); ?>
    <div class="modal-dialog modal-<?php echo e($size ?? 'md'); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4" id="myLargeModalLabel"><?php echo e($title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <?php echo $body; ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn  btn-<?php echo e($submit_class ?? 'primary'); ?>"><?php echo e($submit_text); ?></button>
            </div>
        </div>
    </div>
</form>
<?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/partials/modal.blade.php ENDPATH**/ ?>