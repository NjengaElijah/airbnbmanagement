<form method="post" action="<?php echo e($action); ?>" class="" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <?php echo csrf_field(); ?>
    <?php echo method_field($method??"post"); ?>
    <div class="modal-dialog modal-<?php echo e($size ?? 'md'); ?>">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title h4 text-danger" id="myLargeModalLabel"><?php echo $title??'<i class="fas fa-exclamation-triangle"></i>
                        Are you sure?'; ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
               
                <?php echo $body; ?>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn  btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="submit"
                    class="btn  btn-<?php echo e($submit_class ?? 'danger'); ?>"><?php echo e($submit_text ?? 'Yes, Proceed'); ?></button>
            </div>
        </div>
    </div>
</form>
<?php /**PATH D:\Coding\laravel\airbnbkenya\airbnbkenya\resources\views/partials/confirm.blade.php ENDPATH**/ ?>